﻿using Interview.Services;
using Microsoft.AspNetCore.Mvc;
using Interview.Models;
using Interview.Interface;

namespace Interview.Controllers
{
    [Route("[Controller]")]
    public class StudentController : Controller
    {
        private readonly IStudentService _studentService;
        public StudentController(IStudentService studentService) {
            _studentService = studentService;
        }
        [HttpGet,Route("{id}")]
        public async Task<Student?> GetStudentDetails(string id)
        {
            return await _studentService.GetStudent(id);
        }
        [HttpPost]
        public async Task<bool> AddStudent(Student student)
        {
            return await _studentService.AddStudent(student);
        }

        [HttpDelete,Route("{id}")]
        public async Task<bool> DeleteStudent(string id)
        {
            try
            {
                await _studentService.DeleteStudent(id);
            }catch(Exception ex) {
                return false;
            }
            return true;
        }

        [HttpPut]
        public async Task<bool> UpdateStudent(Student student)
        {
            try
            {
                await _studentService.UpdateStudent(student);
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

    }
}
