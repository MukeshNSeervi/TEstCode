﻿using Interview.Models;

namespace Interview.Interface

{
    public interface IStudentService
    {
        public Task<Student?> GetStudent(string studentID);
        public Task<bool> AddStudent(Student student);
        public Task<bool> UpdateStudent(Student student);
        public Task<bool> DeleteStudent(string studentID);
    }
}
