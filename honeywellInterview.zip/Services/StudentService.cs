﻿using Interview.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using Microsoft.Extensions.Options;
using Interview.Interface;

namespace Interview.Services
{
    public class StudentService :   IStudentService
    {
        private readonly IMongoCollection<Student> _studentCollection;
        private readonly MongoDBSettings _mongoSettings;
        public StudentService(IOptions<MongoDBSettings> mongoDBSettings) 

        {
            _mongoSettings = mongoDBSettings.Value!;
            _studentCollection = new MongoClient(_mongoSettings.MongoDBConnectionString)
                                .GetDatabase(_mongoSettings.DatabaseName)
                                .GetCollection<Student>(_mongoSettings.StudentCollection);
        }

        public async Task<bool> AddStudent(Student student)
        {
            try
            {
                await _studentCollection.InsertOneAsync(student);
                 return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }

       

        public async Task<bool> DeleteStudent(string studentID)
        {
            var filter = Builders<Student>.Filter.Eq("_id", int.Parse(studentID));
            await _studentCollection.DeleteOneAsync(filter);
            return true;
        }

        public async Task<Student?> GetStudent(string studentID)
        {
            var filter = Builders<Student>.Filter.Eq("_id", int.Parse(studentID));
            var response =  _studentCollection.Find(filter).FirstOrDefault();
            return response;
        }


        public async Task<bool> UpdateStudent(Student studentName)
        {
            
            var filter = Builders<Student>.Filter.Eq("_id", studentName.Id);
            var update = Builders<Student>.Update.Set("name", studentName.Name);
            await _studentCollection.UpdateOneAsync(filter,update);
            return true;
        }

        //public async 
    }
}
